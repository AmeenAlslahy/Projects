﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace ag_3
{
    public class Step
    {
        public Point vertex, start, end;
        public string value;
        
        public bool isLabel;
        public Brush color = Brushes.CornflowerBlue;
        public Step()
        {
            vertex = start = end = new Point();
            value = "";
        }
        public Step(Point vertex, Point start, Point end, string value)
        {
            this.vertex = this.start = this.end = new Point();
            this.vertex = vertex;
            this.start = start;
            this.end = end;
            this.value = value;
        }
        public Step(Point vertex, Point start, Point end, string value,Brush color)
        {
            this.vertex = this.start = this.end = new Point();
            this.vertex = vertex;
            this.start = start;
            this.end = end;
            this.value = value;
            this.color = color;
            
        }
        public Step(Point vertex,string value,bool isLabel=false)
        {
            this.vertex = vertex;
            this.value = value;
            this.isLabel = isLabel;
        }
        public Step(Point vertex, string value, Brush color)
        {
            this.vertex = vertex;
            this.value = value;
            this.color = color;
        }
    }
}