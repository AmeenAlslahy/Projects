﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ag_3
{
    partial class Form1
    {
        private void onCheckedWeightedOrUnweighted(object sender, EventArgs e)
        {
            vertexesNumber.Enabled = true;

            weightsArrayArea.Visible = FormData.isWeighted = (sender == isWeighted);
            if (!FormData.isWeighted || numberOfVertex <= 0) return;
                createWeightsArrayArea();
            if (vertexesNamesCount > 1)
            {
                for (int i = 1; i < vertexesNamesCount; i++)
                    weightesArray[0, i].Text = weightesArray[i, 0].Text = neghboursArray[0, i].Text;
            }

        }

        private void onCheckedDirOrundir(object sender, EventArgs e)
        {
            FormData.isDirected = (sender == isDircted);

        }
        private void onCheckedTreeOrGraph(object sender, EventArgs e)
        {

            problemsList.Items.Clear();



            if (sender == isGraph)
            {

                FormData.isGraph = true;
                dirOrUndir.Enabled = true;
                weightedOrUnweighted.Enabled = true;
                string[] graphItem = { "اجتياز الرسم البياني", "المسار الاقصر" };
                problemsList.Items.AddRange(graphItem);
            }
            else
            {

                string[] treeItm = { "اجتياز الشجرة", "ارتفاع الشجرة" };
                FormData.isGraph = false;
                dirOrUndir.Enabled = false;
                weightedOrUnweighted.Enabled = false;
                problemsList.Items.AddRange(treeItm);
                weightsArrayArea.Controls.Clear();
                weightsArrayArea.Visible = false;
                vertexesNumber.Enabled = true;
            }


        }



    }
}
