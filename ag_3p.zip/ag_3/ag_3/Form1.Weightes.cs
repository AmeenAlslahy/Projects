﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ag_3
{
    partial class Form1
    {

        private void saveWeightsButton_Click(object sender, EventArgs e)
        {
            disableArray(weightesArray);

            saveWeightsButton.Enabled = false;

            editWeightsButton.Enabled = true;
            deleteWeightsButton.Enabled = true;

            problemsList.Enabled = true;
            FormData.isWeighted = true;
            Draw.set(neghboursArray, weightesArray, vertexesNames);
            Draw.drawGraph(drawingArea);
            //draw();
            //if (data.isWeighted)
            //    Draw.drawGraph(drawingArea, neghboursArray, weightesArray, vertexesNames);
            //else
            //    Draw.drawGraph(drawingArea, neghboursArray, vertexesNames);
        }

        private void editWeightesButton_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < numberOfVertex; i++)
            {
                for (int j = 1; j < numberOfVertex; j++)
                {
                    if (i != j && neghboursArray[i , j ].Text == "1")
                        weightesArray[i, j].Enabled = true;
                }

            }
            editWeightsButton.Enabled = false;
            saveWeightsButton.Enabled = true;
        }
        private void onEditWeightesValue(object s, EventArgs e)
        {
            string temp = ((TextBox)s).Text.Trim();
            if (temp == null || temp == "") return;
            if (!isNumber((TextBox)s)) return;


            for (int i = 1; i < numberOfVertex; i++)
            {

                for (int j = 1; j < numberOfVertex; j++)
                {
                    if (weightesArray[i, j] == s)
                    {
                        int num = Convert.ToInt32(temp);
                        if (!FormData.isDirected)
                        {
                            weightesArray[j, i].Text = weightesArray[i, j].Text;
                        }
                    }

                }
            }
           
        }
        void createWeightsArrayArea()
        {
            weightsArrayArea.Controls.Clear();
            weightsArrayArea.Controls.Add(weightsArrayLabel);

            weightesArray = new TextBox[numberOfVertex, numberOfVertex];
            drawNeghboursArrayBox(weightsArrayArea, weightesArray);
            weightsArrayArea.Enabled = false; // added with me
        }


    }
}
