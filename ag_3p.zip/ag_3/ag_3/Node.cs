﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace ag_3
{
    public class Node
    {
        public string value;
        public Point vertex, parent;
        public Node left, right;
    }
}
