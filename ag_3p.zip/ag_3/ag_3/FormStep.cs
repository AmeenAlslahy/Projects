﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ag_3
{
    public partial class FormStep : Form
    {
        TextBox[,] neghbor; TextBox[,] weightes; string[] vertexesNames;
        int count = 0;
        public FormStep()
        {
            InitializeComponent();
            drawingArea.Paint += new PaintEventHandler(DrawGraphics);
        }
        public FormStep( string name, string problem, string required, string solve)
        {
            InitializeComponent();
            
            checkRadio();

            vertexesNumber.Text = $"{Draw.numberOfVertex-1}";
            vertexesLabels.Text = name;

            comboValue(problem, required, solve);
            //drawingArea.Controls.Add(p);
            panel3.Enabled = false;
            drawingArea.Paint+=new PaintEventHandler(DrawGraphics);
            //panel2 =drawingArea;
            Graph[] g = Draw.setGraph(panel2);
            //Draw.setGraph(panel2,neber,nm);
            Algorithms.BFSC(g);
        }
        private void DrawGraphics(object sender, PaintEventArgs e)
        {
            Draw.drawGraph(drawingArea);

        }
        public void checkRadio()
        {
            isTree.Checked = !FormData.isGraph;
            isGraph.Checked = FormData.isGraph;

            isDircted.Checked = FormData.isDirected;
            isUUndircted.Checked = !FormData.isDirected;

            isWeighted.Checked = FormData.isWeighted;
            isUnweighted.Checked = !FormData.isWeighted;
        }
        public void comboValue(string problem, string required, string solve)
        {

            problemsList.Items.Add(problem);
            requirementsList.Items.Add(required);
            algResultList.Items.Add(solve);
            problemsList.SelectedIndex = requirementsList.SelectedIndex = algResultList.SelectedIndex = 0;
        }
        private void runStepsButton_Click(object sender,EventArgs e) {
            
            Draw.drawStep(Draw.steps[count++], panel2);
            
        }

    }
}
