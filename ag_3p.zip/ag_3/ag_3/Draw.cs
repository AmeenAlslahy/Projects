﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
namespace ag_3
{
    public class Draw
    {
        
        public static Panel drawingArea = new Panel();
        public static TextBox[,] neghbor;
        public static TextBox[,] weightes;
        public static string[] vertexesNames;
        public static int numberOfVertex = 3;
        public static Graphics graphics;
        public static int cirSize;
        public static Font font;
        public static Point[] nodes;
        public static List<Step> steps = new List<Step>();
        public static void set(TextBox[,] n, string[] names)
        {
            vertexesNames = names;
            numberOfVertex = n.GetLength(0);
            neghbor = n;
            nodes = new Point[numberOfVertex - 1];
            cirSize = drawingArea.Width / (numberOfVertex * 3);
            font = new Font("Arial", cirSize / 2);
            nodes = new Point[numberOfVertex - 1];
        }
        public static void set(TextBox[,] n,TextBox[,] w ,string[] names)
        {
            weightes = w;
            set(n, names);
        }
        public static Node setTree(Panel p ,TextBox [,] t)
        {

            Point center = new Point(p.Width / 2, 20);
            neghbor = t;
            drawingArea = p;
            numberOfVertex = t.GetLength(0);
            Node n=new Node ();
            n.vertex = n.parent = center;
            setTree(ref n, center);
            return n;
            
        }

        static void setTree(ref Node n,Point p,int i=1,int d=1)
        {
            int inc = Convert.ToInt32(drawingArea.Width / (int)Math.Pow(2, d + 1));
            bool r = false;
            n.value = vertexesNames[i-1];

            for (int j = i + 1; j < numberOfVertex ; j++)
            {
                if (neghbor[i, j].Text.Trim().Length > 0)
                {
                    Point child;
                    if (!r)
                    {
                        child = new Point(p.X - inc, p.Y + 50);
                        n.left = new Node();
                        n.left.parent = n.vertex;
                        n.left.vertex = child;
                        r = true;
                        setTree(ref n.left,child,j,d+1);
                    }
                    else
                    {
                        child = new Point(p.X + inc, p.Y + 50);
                        n.right = new Node();
                        n.right.parent = n.vertex;
                        n.right.vertex = child;
                        setTree(ref n.right, child, j, d + 1);
                    }



                }

            }
        }
       
        public static Graph[] setGraph(Panel p)
        {
            
            
            drawingArea = p;
            graphics = p.CreateGraphics();

            Graph[] g = new Graph[numberOfVertex];
            drawNodes();
            setGraph(g);
            return g;
        }
        static void setGraph(Graph[] g)
        {

            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                g[i] = new Graph();
                g[i].vertex = nodes[i];
                g[i].value = vertexesNames[i];
                int k;
                if (FormData.isDirected) k = 0;
                else k = i + 1;
                for (int j = k; j < numberOfVertex - 1; j++)
                {
                    if (neghbor[i+1, j+1].Text.Trim().Length > 0)
                    {
                        g[i].children.Add(j);
                        if(FormData.isWeighted)
                            g[i].weightes.Add(weightes[i,j].Text);
                    }

                }
            }
        }


        public static void drawStep(Step s, Panel p)
        {
            graphics = p.CreateGraphics();
            drawingArea = p;
            if (!s.isLabel)
                drawNode(s.vertex, s.color);
            drawNodeLabel(s.vertex, s.value);
            drawArrow(s.start, s.end);
        }
        public static void drawTree(Panel p)
        {

            drawingArea = p;
            graphics = p.CreateGraphics();

            graphics.Clear(drawingArea.BackColor);

            Point center = new Point(drawingArea.Width / 2, 10);
            drawTree(center);

        }


        public static void drawGraph(Panel p)
        {
            graphics = p.CreateGraphics();
            drawingArea = p;

            graphics.Clear(drawingArea.BackColor);

            drawGraph();
        }
        static void drawGraph()
        {
            drawNodes();
            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                drawNode(nodes[i]);
                drawNodeLabel(nodes[i], vertexesNames[i]);
                int k;
                if (FormData.isDirected) k = 0;
                else k = i + 1;
                for (int j = k; j < numberOfVertex - 1; j++)
                {
                    if (neghbor[i + 1, j + 1].Text.Trim().Length > 0)
                        drawArrow(nodes[i], nodes[j], i, j);
                }
            }

        }
        static void drawTree(Point p, int i = 1, int d = 1)
        {
            int inc = Convert.ToInt32(drawingArea.Width / (int)Math.Pow(2, d + 1));
            bool r = false;
            drawNode(p);
            drawNodeLabel(p, vertexesNames[i - 1]);
            for (int j = i + 1; j < numberOfVertex - 1; j++)
            {
                if (neghbor[i, j].Text.Trim().Length > 0)
                {
                    Point child;
                    if (!r)
                    {
                        child = new Point(p.X - inc, p.Y + 50);
                        r = true;
                    }
                    else
                        child = new Point(p.X + inc, p.Y + 50);
                    drawArrow(p, child);
                    drawTree(child, j, d + 1);

                }

            }
        }
        static void drawNode(Point p)
        {
            graphics.FillEllipse(Brushes.CornflowerBlue, p.X - cirSize / 2, p.Y - cirSize / 2, cirSize, cirSize);

        }
        public static void drawNode(Point p, Brush b)
        {
            graphics.FillEllipse(b, p.X - cirSize / 2, p.Y - cirSize / 2, cirSize, cirSize);

        }
        public static void drawNodeLabel(Point p, string v)
        {
            Brush textBrush = Brushes.Black;

            SizeF textSize = graphics.MeasureString(v, font);
            float textX = p.X + (cirSize - textSize.Width) / 2 - cirSize / 2;
            float textY = p.Y + (cirSize + cirSize / 10 - textSize.Height) / 2 - cirSize / 2;
            graphics.DrawString(v, font, Brushes.Yellow, textX, textY);

        }
        static void drawArrow(Point start, Point end, int i = 0, int j = 0)
        {
            if (start.X == end.X && start.Y == end.Y) return;
            double angle = Math.Atan2(end.Y - start.Y, end.X - start.X);

            start.X += (int)(cirSize / 2 * Math.Cos(angle));
            start.Y += (int)(cirSize / 2 * Math.Sin(angle));

            end.X -= (int)(cirSize / 2 * Math.Cos(angle));
            end.Y -= (int)(cirSize / 2 * Math.Sin(angle));

            graphics.DrawLine(Pens.Red, start, end);

            if (FormData.isDirected)
            {

                double an = Math.PI / (cirSize / 2);

                Point p1 = new Point(
                    end.X - (int)(cirSize * Math.Cos(angle - an)),
                    end.Y - (int)(cirSize * Math.Sin(angle - an))
                );

                Point p2 = new Point(
                    end.X - (int)(cirSize * Math.Cos(angle + an)),
                    end.Y - (int)(cirSize * Math.Sin(angle + an))
                );


                Point[] pp = { end, p1, p2 };
                graphics.FillPolygon(Brushes.Blue, pp);
                graphics.DrawPolygon(Pens.White, pp);
            }

            if (!FormData.isWeighted) return;

            start.X += (int)(cirSize * 3 * Math.Cos(angle));
            start.Y += (int)(cirSize * 3 * Math.Sin(angle));
            Point ppp = new Point((start.X + end.X - numberOfVertex * 5) / 2, (start.Y + end.Y - numberOfVertex * 5) / 2 - numberOfVertex * 5);
            // (weightesArray[i, j] != null)
            graphics.DrawString(weightes[i +1, j +1].Text, font, Brushes.White, start);


        }

        public static void drawNodes()
        {

            int radius = (drawingArea.Height - cirSize * 2) / 2;
            Point center = new Point(drawingArea.Width / 2, drawingArea.Height / 2);
            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                double angle = (i) * 2 * Math.PI / (numberOfVertex - 1);
                int x = center.X + (int)(radius * Math.Cos(angle));
                int y = center.Y + (int)(radius * Math.Sin(angle));
                nodes[i] = new Point(x, y);
            }


            for (int i = 0; i < numberOfVertex - 1; i++)
                drawNode(nodes[i]);

        }
    }
}
