﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ag_3
{
    public class FormData
    {
        public static bool isGraph;
        public static bool isDirected;
        public static bool isWeighted;
        
    }
}
