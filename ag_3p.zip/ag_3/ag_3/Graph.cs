﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace ag_3
{
    public class Graph
    {
        public string value;
        public Point vertex;
        public int mark = 0;
        public Brush color = Brushes.White;
        public Graph pi = null;
        public int timed,timef;
        public List<int> children = new List<int>();
        public List<string> weightes = new List<string>();

    }
    class Graph2
    {
        public string value;
        public Point vertex;
        public List<Graph2> children = new List<Graph2>();
       
    }
}
