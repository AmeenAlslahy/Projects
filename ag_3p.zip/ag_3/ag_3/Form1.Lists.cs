﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ag_3
{
    partial class Form1
    {
        
        private void problemsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            algResultList.Items.Clear();
            requirementsList.Items.Clear();
            requirementsList.Enabled = true;
            string problem = problemsList.Text;
            switch (problem)
            {
                case "اجتياز الشجرة":
                    requirementsList.Items.Add("اجتياز الشجرة الثنائية");
                    break;
                case "ارتفاع الشجرة":
                    requirementsList.Items.Add("ايجاد ارتفاع الشجرة");
                    break;
                case "اجتياز الرسم البياني":
                    string[] requiredItem = { "بحث العمق اولا", "بحث العرض اولا", "الاجتياز الاقل كلفة للشجرة" };
                    requirementsList.Items.AddRange(requiredItem);
                    break;
                case "المسار الاقصر":
                    //requirementsList.Enabled = true;
                    requirementsList.Items.Add("ايجاد المسار الاقصر");
                    break;
             }
            return;
           /* if (problemsList.SelectedItem == "اجتياز الشجرة")
            {

                requirementsList.Items.Add("ارتفاع الشجرة الثنائية");
            }
            else if (problemsList.SelectedItem == "ارتفاع الشجرة")
            {
                requirementsList.Enabled = true;
                requirementsList.Items.Add("ايجاد ارتفاع الشجرة");
            }
            else if (problemsList.SelectedItem == "اجتياز الرسم البياني")
            {
                string[] requiredItem = { "بحث العمق اولا", "بحث العرض اولا", "الاجتياز الاقل كلفة للشجرة" };
                requirementsList.Items.AddRange(requiredItem);
            }
            else if (problemsList.SelectedItem == "المسار الاقصر")
            {
                requirementsList.Enabled = true;
                requirementsList.Items.Add("ايجاد المسار الاقصر");
            }
            //requirementsList.Text = requirementsList.Items[0].ToString();
            */
        }

        private void requirementsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            algResultList.Enabled = true;
            algResultList.Items.Clear();
            string req = requirementsList.Text;
            
            switch (requirementsList.Text)
            {
                case "اجتياز الشجرة الثنائية":
            
                string[] algResultItem = { "اجتياز بالترتيب السابق", "اجتياز بالترتيب الداخل", "اجتياز بالترتيب الاحق" };
                algResultList.Items.AddRange(algResultItem);
                    break;

                case "ايجاد ارتفاع الشجرة":
                    algResultList.Items.Add("خوارزمية ايجاد ارتفاع الشجرة");
                    break;
                case "بحث العمق اولا":
            
                    string[] deepItem = { "خوارزمية اجتياز البحث بالعمق اولا", "خوارزمية اجتياز البحث بالعمق اولا مع التلوين" };
                    algResultList.Items.AddRange(deepItem);
                    break;

                case "بحث العرض اولا":
                    string[] searchWidth = { "خوارزمية اجتياز البحث بالعرض اولا", "خوارزمية اجتياز البحث بالعرض اولا مع التلوين" };
                    algResultList.Items.AddRange(searchWidth);
                    break;
                case "الاجتياز الاقل كلفة للشجرة":
                    string[] tree = { "خوارزمية بريم الاساسية", "خوارزمية بريم المتقدمة", "خوارزمية كروسكال الاساسية", "خوارزمية كروسكال المتقدمة" };
                    algResultList.Items.AddRange(tree);
                    break;
                case "ايجاد المسار الاقصر":
                    string[] str = { "خوارزمية القوة الخاشمة", "خوارزمية فلوريد", "خوارزمية ديجسترا", "خوارزمية بليمان" };
                    algResultList.Items.AddRange(str);
                    break;
        }
            /*
            if (requirementsList.Items.Count > 0)
                if (requirementsList.SelectedItem == "اجتياز الشجرة الثنائية")
                {
                    string[] algResultItem = { "اجتياز بالترتيب السابق", "اجتياز بالترتيب الداخل", "اجتياز بالترتيب الاحق" };
                    algResultList.Items.AddRange(algResultItem);
                }

                else if (requirementsList.SelectedItem == "ايجاد ارتفاع الشجرة")
                    algResultList.Items.Add("خوارزمية ايجاد ارتفاع الشجرة");

                else if (requirementsList.SelectedItem == "بحث العمق اولا")
                {
                    string[] deepItem = { "خوارزمية اجتياز البحث بالعمق اولا", "خوارزمية اجتياز البحث بالعمق اولا مع التلوين" };
                    algResultList.Items.AddRange(deepItem);
                }

                else if (requirementsList.SelectedItem == "بحث العرض اولا")
                {
                    string[] searchWidth = { "خوارزمية اجتياز البحث بالعرض اولا", "خوارزمية اجتياز البحث بالعرض اولا مع التلوين" };
                    algResultList.Items.AddRange(searchWidth);
                }

                else if (requirementsList.SelectedItem == "الاجتياز الاقل كلفة للشجرة")
                {
                    string[] searchWidth = { "خوارزمية بريم الاساسية", "خوارزمية بريم المتقدمة", "خوارزمية كروسكال الاساسية", "خوارزمية كروسكال المتقدمة" };
                    algResultList.Items.AddRange(searchWidth);
                }

                else if (requirementsList.SelectedItem == "ايجاد المسار الاقصر")
                {
                    string[] str = { "خوارزمية القوة الخاشمة", "خوارزمية فلوريد", "خوارزمية ديجسترا", "خوارزمية بليمان" };
                    algResultList.Items.AddRange(str);
                }
                */
            //algResultList.Text = algResultList.Items[0].ToString();
        }
        private void algResultsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            runStepsButton.Enabled = true;
        }
    }
}
