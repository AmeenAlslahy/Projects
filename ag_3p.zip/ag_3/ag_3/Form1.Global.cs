﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace ag_3
{
    partial class Form1
    {
        int getCellValue(string s)
        {

            try
            {
                return Convert.ToInt32(s);

            }
            catch (Exception e)
            {

                return 0;
            }

        }



        void deleteArraysButton(TextBox[,] pixels, int s = 1)
        {
            for (int i = s; i < numberOfVertex; i++)
            {
                for (int j = s; j < numberOfVertex; j++)
                {
                    if (pixels[i, j] != null)
                        pixels[i, j].Text = "";


                }
            }

        }


        void disableArray(TextBox[,] arr, bool s = false)
        {
            for (int i = 1; i < numberOfVertex; i++)
            {
                for (int j = 1; j < numberOfVertex; j++)
                    if (i != j)
                        arr[i, j].Enabled = s;

            }
        }
        void drawNeghboursArrayBox(Panel p, TextBox[,] arr, char t = 'w')
        {
            //int sizeOfBox = (neghborArrayArea.Width - 10) / (numberOfVertex);
            //int top = 30;
            //int left = 5;



            //for (int i = 0; i < numberOfVertex; i++)
            //{
            //    for (int j = 0; j < numberOfVertex; j++)
            //    {
            //        if (i == 0 && j == 0) continue;
            //        arr[i, j] = new TextBox();
            //        arr[i, j].Top = top + (sizeOfBox * i);
            //        arr[i, j].Left = left + (sizeOfBox * j);
            //        arr[i, j].Size = new Size(sizeOfBox, sizeOfBox);
            //        arr[i, j].Name = "N" + i.ToString() + j.ToString();
            //        arr[i, j].Multiline = true;
            //        if (i == j || i == 0 || j == 0)
            //            arr[i, j].Enabled = false;
            //        if (t == 'n') arr[i, j].KeyPress += onEditNeghborValue;
            //        else arr[i, j].KeyPress += onEditWeightesValue;
            //        p.Controls.Add(arr[i, j]);


            //    }
            //} 
            if (numberOfVertex > 0)
            {
                for (int i = 0; i < numberOfVertex; i++)
            {
                for (int j = 0; j < numberOfVertex; j++)
                {
                    arr[i, j] = new TextBox();
                    arr[i, j].Size = new Size(boxSize, boxSize);
                    arr[i, j].Multiline = true;
                    arr[i, j].Top =margin+ (i  * boxSize) ;
                    arr[i, j].Left = j * boxSize;

                    arr[i, j].Name = $"N{i}{j}";

                    if (i == j || i == 0 || j == 0)
                        arr[i, j].Enabled = false;
                    if (t == 'n') arr[i, j].KeyPress += onEditNeghborValue;
                    else arr[i, j].Leave += onEditWeightesValue;
                    p.Controls.Add(arr[i, j]);
                }
            }
            arr[0, 0].Visible = false;
        }
            else
                MessageBox.Show("please Enter the count of nodes");
        }

        bool isNumber(TextBox t)
        {
            try
            {
                Convert.ToInt32(t.Text.Trim());
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show("ادخل عدد صالح...");

                t.Focus();
                return false;
            }

        }




    }
}
