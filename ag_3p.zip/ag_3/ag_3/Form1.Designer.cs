﻿namespace ag_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.graphOrTree = new System.Windows.Forms.Panel();
            this.isGraph = new System.Windows.Forms.RadioButton();
            this.isTree = new System.Windows.Forms.RadioButton();
            this.dirOrUndir = new System.Windows.Forms.Panel();
            this.isUUndircted = new System.Windows.Forms.RadioButton();
            this.isDircted = new System.Windows.Forms.RadioButton();
            this.weightedOrUnweighted = new System.Windows.Forms.Panel();
            this.isUnweighted = new System.Windows.Forms.RadioButton();
            this.isWeighted = new System.Windows.Forms.RadioButton();
            this.graphProprerisLabel = new System.Windows.Forms.Label();
            this.problem = new System.Windows.Forms.Label();
            this.algResult = new System.Windows.Forms.Label();
            this.requirement = new System.Windows.Forms.Label();
            this.problemsList = new System.Windows.Forms.ComboBox();
            this.requirementsList = new System.Windows.Forms.ComboBox();
            this.algResultList = new System.Windows.Forms.ComboBox();
            this.vertexesNumberLabel = new System.Windows.Forms.Label();
            this.vertexesLabelsLabel = new System.Windows.Forms.Label();
            this.vertexesLabels = new System.Windows.Forms.TextBox();
            this.vertexesNumber = new System.Windows.Forms.TextBox();
            this.motherPanel = new System.Windows.Forms.Panel();
            this.saveNeghborButton = new System.Windows.Forms.Button();
            this.editWeightsButton = new System.Windows.Forms.Button();
            this.deleteWeightsButton = new System.Windows.Forms.Button();
            this.drawingArea = new System.Windows.Forms.Panel();
            this.drawingLabel = new System.Windows.Forms.Label();
            this.saveWeightsButton = new System.Windows.Forms.Button();
            this.editNeghborButton = new System.Windows.Forms.Button();
            this.neghborArrayArea = new System.Windows.Forms.Panel();
            this.neghborArrayLabel = new System.Windows.Forms.Label();
            this.deleteNeghborButton = new System.Windows.Forms.Button();
            this.weightsArrayArea = new System.Windows.Forms.Panel();
            this.weightsArrayLabel = new System.Windows.Forms.Label();
            this.editAllButton = new System.Windows.Forms.Button();
            this.runStepsButton = new System.Windows.Forms.Button();
            this.deleteAllButton = new System.Windows.Forms.Button();
            this.homeButton = new System.Windows.Forms.Button();
            this.graphOrTree.SuspendLayout();
            this.dirOrUndir.SuspendLayout();
            this.weightedOrUnweighted.SuspendLayout();
            this.motherPanel.SuspendLayout();
            this.drawingArea.SuspendLayout();
            this.neghborArrayArea.SuspendLayout();
            this.weightsArrayArea.SuspendLayout();
            this.SuspendLayout();
            // 
            // graphOrTree
            // 
            this.graphOrTree.Controls.Add(this.isGraph);
            this.graphOrTree.Controls.Add(this.isTree);
            this.graphOrTree.Location = new System.Drawing.Point(1052, 48);
            this.graphOrTree.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.graphOrTree.Name = "graphOrTree";
            this.graphOrTree.Size = new System.Drawing.Size(93, 84);
            this.graphOrTree.TabIndex = 1;
            // 
            // isGraph
            // 
            this.isGraph.AutoSize = true;
            this.isGraph.Location = new System.Drawing.Point(27, 43);
            this.isGraph.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isGraph.Name = "isGraph";
            this.isGraph.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isGraph.Size = new System.Drawing.Size(66, 21);
            this.isGraph.TabIndex = 1;
            this.isGraph.Text = "مخطط";
            this.isGraph.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isGraph.UseVisualStyleBackColor = true;
            this.isGraph.CheckedChanged += new System.EventHandler(this.onCheckedTreeOrGraph);
            // 
            // isTree
            // 
            this.isTree.AutoSize = true;
            this.isTree.Location = new System.Drawing.Point(28, 15);
            this.isTree.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isTree.Name = "isTree";
            this.isTree.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isTree.Size = new System.Drawing.Size(66, 21);
            this.isTree.TabIndex = 0;
            this.isTree.Text = "شجرة";
            this.isTree.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isTree.UseVisualStyleBackColor = true;
            this.isTree.CheckedChanged += new System.EventHandler(this.onCheckedTreeOrGraph);
            // 
            // dirOrUndir
            // 
            this.dirOrUndir.Controls.Add(this.isUUndircted);
            this.dirOrUndir.Controls.Add(this.isDircted);
            this.dirOrUndir.Location = new System.Drawing.Point(952, 48);
            this.dirOrUndir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dirOrUndir.Name = "dirOrUndir";
            this.dirOrUndir.Size = new System.Drawing.Size(93, 84);
            this.dirOrUndir.TabIndex = 2;
            // 
            // isUUndircted
            // 
            this.isUUndircted.AutoSize = true;
            this.isUUndircted.Location = new System.Drawing.Point(10, 43);
            this.isUUndircted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isUUndircted.Name = "isUUndircted";
            this.isUUndircted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isUUndircted.Size = new System.Drawing.Size(82, 21);
            this.isUUndircted.TabIndex = 1;
            this.isUUndircted.Text = "غير موجه";
            this.isUUndircted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isUUndircted.UseVisualStyleBackColor = true;
            this.isUUndircted.CheckedChanged += new System.EventHandler(this.onCheckedDirOrundir);
            // 
            // isDircted
            // 
            this.isDircted.AutoSize = true;
            this.isDircted.Location = new System.Drawing.Point(33, 15);
            this.isDircted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isDircted.Name = "isDircted";
            this.isDircted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isDircted.Size = new System.Drawing.Size(59, 21);
            this.isDircted.TabIndex = 0;
            this.isDircted.Text = "موجه";
            this.isDircted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isDircted.UseVisualStyleBackColor = true;
            this.isDircted.CheckedChanged += new System.EventHandler(this.onCheckedDirOrundir);
            // 
            // weightedOrUnweighted
            // 
            this.weightedOrUnweighted.Controls.Add(this.isUnweighted);
            this.weightedOrUnweighted.Controls.Add(this.isWeighted);
            this.weightedOrUnweighted.Location = new System.Drawing.Point(852, 48);
            this.weightedOrUnweighted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weightedOrUnweighted.Name = "weightedOrUnweighted";
            this.weightedOrUnweighted.Size = new System.Drawing.Size(93, 84);
            this.weightedOrUnweighted.TabIndex = 2;
            // 
            // isUnweighted
            // 
            this.isUnweighted.AutoSize = true;
            this.isUnweighted.Location = new System.Drawing.Point(3, 43);
            this.isUnweighted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isUnweighted.Name = "isUnweighted";
            this.isUnweighted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isUnweighted.Size = new System.Drawing.Size(85, 21);
            this.isUnweighted.TabIndex = 1;
            this.isUnweighted.Text = "غير موزون";
            this.isUnweighted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isUnweighted.UseVisualStyleBackColor = true;
            this.isUnweighted.CheckedChanged += new System.EventHandler(this.onCheckedWeightedOrUnweighted);
            // 
            // isWeighted
            // 
            this.isWeighted.AutoSize = true;
            this.isWeighted.Location = new System.Drawing.Point(26, 15);
            this.isWeighted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isWeighted.Name = "isWeighted";
            this.isWeighted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isWeighted.Size = new System.Drawing.Size(62, 21);
            this.isWeighted.TabIndex = 0;
            this.isWeighted.Text = "موزون";
            this.isWeighted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isWeighted.UseVisualStyleBackColor = true;
            this.isWeighted.CheckedChanged += new System.EventHandler(this.onCheckedWeightedOrUnweighted);
            // 
            // graphProprerisLabel
            // 
            this.graphProprerisLabel.AutoSize = true;
            this.graphProprerisLabel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.graphProprerisLabel.Location = new System.Drawing.Point(926, 23);
            this.graphProprerisLabel.Name = "graphProprerisLabel";
            this.graphProprerisLabel.Size = new System.Drawing.Size(152, 21);
            this.graphProprerisLabel.TabIndex = 0;
            this.graphProprerisLabel.Text = "نوع الرسم وخصائصه";
            // 
            // problem
            // 
            this.problem.AutoSize = true;
            this.problem.Location = new System.Drawing.Point(254, 17);
            this.problem.Name = "problem";
            this.problem.Size = new System.Drawing.Size(59, 17);
            this.problem.TabIndex = 3;
            this.problem.Text = "المشكلة";
            // 
            // algResult
            // 
            this.algResult.AutoSize = true;
            this.algResult.Location = new System.Drawing.Point(252, 110);
            this.algResult.Name = "algResult";
            this.algResult.Size = new System.Drawing.Size(87, 17);
            this.algResult.TabIndex = 4;
            this.algResult.Text = "خوارزمية الحل";
            // 
            // requirement
            // 
            this.requirement.AutoSize = true;
            this.requirement.Location = new System.Drawing.Point(257, 68);
            this.requirement.Name = "requirement";
            this.requirement.Size = new System.Drawing.Size(56, 17);
            this.requirement.TabIndex = 5;
            this.requirement.Text = "المطلوب";
            // 
            // problemsList
            // 
            this.problemsList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.problemsList.FormattingEnabled = true;
            this.problemsList.Location = new System.Drawing.Point(14, 14);
            this.problemsList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.problemsList.Name = "problemsList";
            this.problemsList.Size = new System.Drawing.Size(212, 24);
            this.problemsList.TabIndex = 6;
            this.problemsList.SelectedIndexChanged += new System.EventHandler(this.problemsList_SelectedIndexChanged);
            // 
            // requirementsList
            // 
            this.requirementsList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.requirementsList.FormattingEnabled = true;
            this.requirementsList.Location = new System.Drawing.Point(14, 63);
            this.requirementsList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.requirementsList.Name = "requirementsList";
            this.requirementsList.Size = new System.Drawing.Size(212, 24);
            this.requirementsList.TabIndex = 7;
            this.requirementsList.SelectedIndexChanged += new System.EventHandler(this.requirementsList_SelectedIndexChanged);
            // 
            // algResultList
            // 
            this.algResultList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.algResultList.FormattingEnabled = true;
            this.algResultList.Location = new System.Drawing.Point(14, 106);
            this.algResultList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.algResultList.Name = "algResultList";
            this.algResultList.Size = new System.Drawing.Size(212, 24);
            this.algResultList.TabIndex = 8;
            // 
            // vertexesNumberLabel
            // 
            this.vertexesNumberLabel.AutoSize = true;
            this.vertexesNumberLabel.Location = new System.Drawing.Point(636, 26);
            this.vertexesNumberLabel.Name = "vertexesNumberLabel";
            this.vertexesNumberLabel.Size = new System.Drawing.Size(77, 17);
            this.vertexesNumberLabel.TabIndex = 9;
            this.vertexesNumberLabel.Text = "عدد الرؤوس";
            // 
            // vertexesLabelsLabel
            // 
            this.vertexesLabelsLabel.AutoSize = true;
            this.vertexesLabelsLabel.Location = new System.Drawing.Point(489, 23);
            this.vertexesLabelsLabel.Name = "vertexesLabelsLabel";
            this.vertexesLabelsLabel.Size = new System.Drawing.Size(102, 17);
            this.vertexesLabelsLabel.TabIndex = 10;
            this.vertexesLabelsLabel.Text = "تسميات الرؤوس";
            // 
            // vertexesLabels
            // 
            this.vertexesLabels.Enabled = false;
            this.vertexesLabels.Location = new System.Drawing.Point(468, 62);
            this.vertexesLabels.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.vertexesLabels.Name = "vertexesLabels";
            this.vertexesLabels.Size = new System.Drawing.Size(116, 24);
            this.vertexesLabels.TabIndex = 11;
            this.vertexesLabels.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onVertexesLabelsKeyPress);
            // 
            // vertexesNumber
            // 
            this.vertexesNumber.Location = new System.Drawing.Point(591, 62);
            this.vertexesNumber.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.vertexesNumber.Name = "vertexesNumber";
            this.vertexesNumber.Size = new System.Drawing.Size(116, 24);
            this.vertexesNumber.TabIndex = 12;
            // 
            // motherPanel
            // 
            this.motherPanel.BackColor = System.Drawing.Color.White;
            this.motherPanel.Controls.Add(this.saveNeghborButton);
            this.motherPanel.Controls.Add(this.editWeightsButton);
            this.motherPanel.Controls.Add(this.deleteWeightsButton);
            this.motherPanel.Controls.Add(this.drawingArea);
            this.motherPanel.Controls.Add(this.saveWeightsButton);
            this.motherPanel.Controls.Add(this.editNeghborButton);
            this.motherPanel.Controls.Add(this.neghborArrayArea);
            this.motherPanel.Controls.Add(this.deleteNeghborButton);
            this.motherPanel.Controls.Add(this.weightsArrayArea);
            this.motherPanel.Location = new System.Drawing.Point(14, 139);
            this.motherPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.motherPanel.Name = "motherPanel";
            this.motherPanel.Size = new System.Drawing.Size(1132, 543);
            this.motherPanel.TabIndex = 13;
            // 
            // saveNeghborButton
            // 
            this.saveNeghborButton.Location = new System.Drawing.Point(788, 509);
            this.saveNeghborButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.saveNeghborButton.Name = "saveNeghborButton";
            this.saveNeghborButton.Size = new System.Drawing.Size(69, 28);
            this.saveNeghborButton.TabIndex = 8;
            this.saveNeghborButton.Text = "حفظ";
            this.saveNeghborButton.UseVisualStyleBackColor = true;
            this.saveNeghborButton.Click += new System.EventHandler(this.saveNeghborButton_Click);
            // 
            // editWeightsButton
            // 
            this.editWeightsButton.Location = new System.Drawing.Point(971, 509);
            this.editWeightsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editWeightsButton.Name = "editWeightsButton";
            this.editWeightsButton.Size = new System.Drawing.Size(69, 28);
            this.editWeightsButton.TabIndex = 4;
            this.editWeightsButton.Text = "تعديل";
            this.editWeightsButton.UseVisualStyleBackColor = true;
            this.editWeightsButton.Click += new System.EventHandler(this.editWeightesButton_Click);
            // 
            // deleteWeightsButton
            // 
            this.deleteWeightsButton.Location = new System.Drawing.Point(895, 509);
            this.deleteWeightsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.deleteWeightsButton.Name = "deleteWeightsButton";
            this.deleteWeightsButton.Size = new System.Drawing.Size(69, 28);
            this.deleteWeightsButton.TabIndex = 3;
            this.deleteWeightsButton.Text = "مسح";
            this.deleteWeightsButton.UseVisualStyleBackColor = true;
            this.deleteWeightsButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // drawingArea
            // 
            this.drawingArea.BackColor = System.Drawing.Color.DarkGray;
            this.drawingArea.Controls.Add(this.drawingLabel);
            this.drawingArea.Location = new System.Drawing.Point(3, 4);
            this.drawingArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.drawingArea.Name = "drawingArea";
            this.drawingArea.Size = new System.Drawing.Size(615, 535);
            this.drawingArea.TabIndex = 2;
            // 
            // drawingLabel
            // 
            this.drawingLabel.AutoSize = true;
            this.drawingLabel.BackColor = System.Drawing.Color.FloralWhite;
            this.drawingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.drawingLabel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.drawingLabel.Location = new System.Drawing.Point(226, 0);
            this.drawingLabel.Name = "drawingLabel";
            this.drawingLabel.Size = new System.Drawing.Size(57, 23);
            this.drawingLabel.TabIndex = 12;
            this.drawingLabel.Text = "الرسم";
            // 
            // saveWeightsButton
            // 
            this.saveWeightsButton.Location = new System.Drawing.Point(1047, 509);
            this.saveWeightsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.saveWeightsButton.Name = "saveWeightsButton";
            this.saveWeightsButton.Size = new System.Drawing.Size(69, 28);
            this.saveWeightsButton.TabIndex = 5;
            this.saveWeightsButton.Text = "حفظ";
            this.saveWeightsButton.UseVisualStyleBackColor = true;
            this.saveWeightsButton.Click += new System.EventHandler(this.saveWeightsButton_Click);
            // 
            // editNeghborButton
            // 
            this.editNeghborButton.Location = new System.Drawing.Point(712, 509);
            this.editNeghborButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editNeghborButton.Name = "editNeghborButton";
            this.editNeghborButton.Size = new System.Drawing.Size(69, 28);
            this.editNeghborButton.TabIndex = 7;
            this.editNeghborButton.Text = "تعديل";
            this.editNeghborButton.UseVisualStyleBackColor = true;
            this.editNeghborButton.Click += new System.EventHandler(this.editNeghborButton_Click);
            // 
            // neghborArrayArea
            // 
            this.neghborArrayArea.BackColor = System.Drawing.Color.DarkGray;
            this.neghborArrayArea.Controls.Add(this.neghborArrayLabel);
            this.neghborArrayArea.Location = new System.Drawing.Point(625, 7);
            this.neghborArrayArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.neghborArrayArea.Name = "neghborArrayArea";
            this.neghborArrayArea.Size = new System.Drawing.Size(246, 494);
            this.neghborArrayArea.TabIndex = 0;
            // 
            // neghborArrayLabel
            // 
            this.neghborArrayLabel.AutoSize = true;
            this.neghborArrayLabel.BackColor = System.Drawing.Color.FloralWhite;
            this.neghborArrayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.neghborArrayLabel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.neghborArrayLabel.Location = new System.Drawing.Point(85, 0);
            this.neghborArrayLabel.Name = "neghborArrayLabel";
            this.neghborArrayLabel.Size = new System.Drawing.Size(112, 23);
            this.neghborArrayLabel.TabIndex = 10;
            this.neghborArrayLabel.Text = "مصفوفة الجوار";
            // 
            // deleteNeghborButton
            // 
            this.deleteNeghborButton.Location = new System.Drawing.Point(636, 509);
            this.deleteNeghborButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.deleteNeghborButton.Name = "deleteNeghborButton";
            this.deleteNeghborButton.Size = new System.Drawing.Size(69, 28);
            this.deleteNeghborButton.TabIndex = 6;
            this.deleteNeghborButton.Text = "مسح";
            this.deleteNeghborButton.UseVisualStyleBackColor = true;
            this.deleteNeghborButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // weightsArrayArea
            // 
            this.weightsArrayArea.BackColor = System.Drawing.Color.DarkGray;
            this.weightsArrayArea.Controls.Add(this.weightsArrayLabel);
            this.weightsArrayArea.Location = new System.Drawing.Point(882, 7);
            this.weightsArrayArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weightsArrayArea.Name = "weightsArrayArea";
            this.weightsArrayArea.Size = new System.Drawing.Size(246, 494);
            this.weightsArrayArea.TabIndex = 1;
            // 
            // weightsArrayLabel
            // 
            this.weightsArrayLabel.AutoSize = true;
            this.weightsArrayLabel.BackColor = System.Drawing.Color.FloralWhite;
            this.weightsArrayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.weightsArrayLabel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.weightsArrayLabel.Location = new System.Drawing.Point(71, 0);
            this.weightsArrayLabel.Name = "weightsArrayLabel";
            this.weightsArrayLabel.Size = new System.Drawing.Size(115, 23);
            this.weightsArrayLabel.TabIndex = 11;
            this.weightsArrayLabel.Text = "مصفوفة الاوزان";
            // 
            // editAllButton
            // 
            this.editAllButton.Location = new System.Drawing.Point(981, 695);
            this.editAllButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editAllButton.Name = "editAllButton";
            this.editAllButton.Size = new System.Drawing.Size(133, 39);
            this.editAllButton.TabIndex = 16;
            this.editAllButton.Text = "تعديل البيانات";
            this.editAllButton.UseVisualStyleBackColor = true;
            this.editAllButton.Click += new System.EventHandler(this.editAllButton_Click);
            // 
            // runStepsButton
            // 
            this.runStepsButton.Location = new System.Drawing.Point(639, 695);
            this.runStepsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.runStepsButton.Name = "runStepsButton";
            this.runStepsButton.Size = new System.Drawing.Size(133, 39);
            this.runStepsButton.TabIndex = 17;
            this.runStepsButton.Text = "التنفيذ خطوة - خطوة";
            this.runStepsButton.UseVisualStyleBackColor = true;
            this.runStepsButton.Click += new System.EventHandler(this.runStepsButton_Click);
            // 
            // deleteAllButton
            // 
            this.deleteAllButton.Location = new System.Drawing.Point(812, 695);
            this.deleteAllButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.deleteAllButton.Name = "deleteAllButton";
            this.deleteAllButton.Size = new System.Drawing.Size(133, 39);
            this.deleteAllButton.TabIndex = 18;
            this.deleteAllButton.Text = "مسح البيانات";
            this.deleteAllButton.UseVisualStyleBackColor = true;
            this.deleteAllButton.Click += new System.EventHandler(this.onLoadForm);
            // 
            // homeButton
            // 
            this.homeButton.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeButton.Location = new System.Drawing.Point(14, 689);
            this.homeButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.homeButton.Name = "homeButton";
            this.homeButton.Size = new System.Drawing.Size(133, 39);
            this.homeButton.TabIndex = 19;
            this.homeButton.Text = "الشاشة الرئيسية";
            this.homeButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1167, 738);
            this.Controls.Add(this.homeButton);
            this.Controls.Add(this.deleteAllButton);
            this.Controls.Add(this.runStepsButton);
            this.Controls.Add(this.editAllButton);
            this.Controls.Add(this.motherPanel);
            this.Controls.Add(this.vertexesNumber);
            this.Controls.Add(this.vertexesLabels);
            this.Controls.Add(this.vertexesLabelsLabel);
            this.Controls.Add(this.vertexesNumberLabel);
            this.Controls.Add(this.algResultList);
            this.Controls.Add(this.requirementsList);
            this.Controls.Add(this.problemsList);
            this.Controls.Add(this.requirement);
            this.Controls.Add(this.algResult);
            this.Controls.Add(this.problem);
            this.Controls.Add(this.graphProprerisLabel);
            this.Controls.Add(this.graphOrTree);
            this.Controls.Add(this.dirOrUndir);
            this.Controls.Add(this.weightedOrUnweighted);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.onLoadForm);
            this.graphOrTree.ResumeLayout(false);
            this.graphOrTree.PerformLayout();
            this.dirOrUndir.ResumeLayout(false);
            this.dirOrUndir.PerformLayout();
            this.weightedOrUnweighted.ResumeLayout(false);
            this.weightedOrUnweighted.PerformLayout();
            this.motherPanel.ResumeLayout(false);
            this.drawingArea.ResumeLayout(false);
            this.drawingArea.PerformLayout();
            this.neghborArrayArea.ResumeLayout(false);
            this.neghborArrayArea.PerformLayout();
            this.weightsArrayArea.ResumeLayout(false);
            this.weightsArrayArea.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel graphOrTree;
        private System.Windows.Forms.RadioButton isGraph;
        private System.Windows.Forms.RadioButton isTree;
        private System.Windows.Forms.Panel dirOrUndir;
        private System.Windows.Forms.RadioButton isUUndircted;
        private System.Windows.Forms.RadioButton isDircted;
        private System.Windows.Forms.Panel weightedOrUnweighted;
        private System.Windows.Forms.RadioButton isUnweighted;
        private System.Windows.Forms.RadioButton isWeighted;
        private System.Windows.Forms.Label graphProprerisLabel;
        private System.Windows.Forms.Label problem;
        private System.Windows.Forms.Label algResult;
        private System.Windows.Forms.Label requirement;
        private System.Windows.Forms.ComboBox problemsList;
        private System.Windows.Forms.ComboBox requirementsList;
        private System.Windows.Forms.ComboBox algResultList;
        private System.Windows.Forms.Label vertexesNumberLabel;
        private System.Windows.Forms.Label vertexesLabelsLabel;
        private System.Windows.Forms.TextBox vertexesLabels;
        private System.Windows.Forms.TextBox vertexesNumber;
        private System.Windows.Forms.Panel motherPanel;
        private System.Windows.Forms.Button saveNeghborButton;
        private System.Windows.Forms.Button editNeghborButton;
        private System.Windows.Forms.Button deleteNeghborButton;
        private System.Windows.Forms.Button saveWeightsButton;
        private System.Windows.Forms.Button editWeightsButton;
        private System.Windows.Forms.Button deleteWeightsButton;
        private System.Windows.Forms.Panel drawingArea;
        private System.Windows.Forms.Label drawingLabel;
        private System.Windows.Forms.Panel weightsArrayArea;
        private System.Windows.Forms.Label weightsArrayLabel;
        private System.Windows.Forms.Panel neghborArrayArea;
        private System.Windows.Forms.Label neghborArrayLabel;
        private System.Windows.Forms.Button editAllButton;
        private System.Windows.Forms.Button runStepsButton;
        private System.Windows.Forms.Button deleteAllButton;
        private System.Windows.Forms.Button homeButton;
    }
}

