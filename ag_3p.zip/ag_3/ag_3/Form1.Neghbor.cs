﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ag_3
{
    partial class Form1
    {
        private void onEditNeghborValue(object s, KeyPressEventArgs e)
        {

            int key = e.KeyChar;
            int len = ((TextBox)s).Text.Length;
            int i = (((TextBox)s).Top-margin) / boxSize;
            int j = ((TextBox)s).Left / boxSize;
            if (!((key == 49 && len <= 0) || key == 8))
            {
                MessageBox.Show("يرحى ادخال قية 1 فقط ");
                e.Handled = true;
                return;
            }
            int temp = getCellValue(e.KeyChar.ToString());
            if (!FormData.isDirected)
            {
                neghboursArray[j, i].Text = e.KeyChar.ToString();
                if (e.KeyChar == 8)
                    neghboursArray[j, i].Text = "";
            }
        }
        private void saveNeghborButton_Click(object sender, EventArgs e)
        {
            Draw.set(neghboursArray,weightesArray ,vertexesNames);
            runStepsButton.Enabled = true;
            saveNeghborButton.Enabled = false;
            editNeghborButton.Enabled = true;
            deleteNeghborButton.Enabled = true;

            disableArray(neghboursArray);
            for (int i = 1; i < numberOfVertex; i++)
            {
                for (int j = 1; j < numberOfVertex; j++)
                {
                    if (FormData.isWeighted)
                    {
                        if (neghboursArray[i, j].Text != "1")
                        {

                            weightesArray[i, j].Enabled = false;
                            weightesArray[i, j].Text = "";
                        }
                        else
                            weightesArray[i, j].Enabled = true;
                    }

                }
            }
            if (FormData.isWeighted)
            {
                weightsArrayArea.Enabled = true;
                saveWeightsButton.Enabled = true;
            }
            if (!FormData.isWeighted )//|| !FormData.isGraph)
                problemsList.Enabled = true;
            if (FormData.isGraph) Draw.drawGraph(drawingArea);
            else Draw.drawTree(drawingArea);
            //draw();
        }
        private void editNeghborButton_Click(object sender, EventArgs e)
        {
            disableArray(neghboursArray, true);
            editNeghborButton.Enabled = false;
            saveNeghborButton.Enabled = true;
        }

    }
}
