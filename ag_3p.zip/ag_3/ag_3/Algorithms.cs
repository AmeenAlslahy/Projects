﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace ag_3
{
    public class Algorithms
    {
        static int count = 0;
        static int numberOfVertex;
        public static void DFS(Graph[] g)
        {
            numberOfVertex = g.GetLength(0);
            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                if (g[i].mark == 0)
                {
                    Step s = new Step(g[i].vertex, g[i].value);
                    Draw.steps.Add(s);
                    dfs(g, i);
                }
            }

        }
        public static void dfs(Graph[] g, int i)
        {
            count++;
            g[i].mark = count;
            Graph u = g[i];

            Step s = new Step(new Point(u.vertex.X + 30, u.vertex.Y), count.ToString(), true);
            Draw.steps.Add(s);
            for (int j = 0; j < u.children.Count; j++)
            {
                int t = u.children[j];
                if (g[t].mark == 0)
                {
                    s = new Step(g[t].vertex, u.vertex, g[t].vertex, g[t].value);
                    Draw.steps.Add(s);
                    dfs(g, t);
                }
            }


        }
        public static void preOrder(Node n)
        {
            // root left right
            if (n != null)
            {
                Step s = new Step(n.vertex, n.vertex, n.parent, n.value);
                Draw.steps.Add(s);
                count++;
                s = new Step(new Point(n.vertex.X + 20, n.vertex.Y), (count).ToString(), true);
                Draw.steps.Add(s);

                preOrder(n.left);
                preOrder(n.right);

            }
        }
        public static void inOrder(Node n)
        {
            //left root right
            if (n != null)
            {

                Step s = new Step(n.vertex, n.vertex, n.parent, n.value);
                Draw.steps.Add(s);

                inOrder(n.left);
                count++;
                s = new Step(new Point(n.vertex.X + 20, n.vertex.Y), (count).ToString(), true);
                Draw.steps.Add(s);
                inOrder(n.right);
            }
        }
        public static void postOrder(Node n)
        {
            // left right root 
            if (n != null)
            {

                Step s = new Step(n.vertex, n.vertex, n.parent, n.value);
                Draw.steps.Add(s);

                postOrder(n.left);
                postOrder(n.right);

                count++;
                s = new Step(new Point(n.vertex.X + 20, n.vertex.Y), (count).ToString(), true);
                Draw.steps.Add(s);

            }
        }

        public static int getHeight(Node n)
        {
            if (n == null) return -1;
            Step s = new Step(n.vertex, n.vertex, n.parent, n.value);
            Draw.steps.Add(s);

            int l = getHeight(n.left);
            int r = getHeight(n.right);
            int m = Math.Max(l, r) + 1;

            s = new Step(new Point(n.vertex.X + 20, n.vertex.Y), m.ToString(), true);
            Draw.steps.Add(s);

            return m;
        }


        public static void DFSC(Graph[] g)
        {
            numberOfVertex = g.GetLength(0);
            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                if (g[i].color == Brushes.White)
                    dfsVisit(g, i);
            }

        }
        public static void dfsVisit(Graph[] g, int i)
        {
            Graph u = g[i];

            g[i].color = Brushes.Gray;

            Point parent;
            if (u.pi == null) parent = u.vertex;
            else parent = u.pi.vertex;
            Step s = new Step(u.vertex, parent, u.vertex, u.value, u.color);
            Draw.steps.Add(s);

            u.timed = count;

            int n = u.children.Count;
            for (int j = 0; j < n; j++)
            {
                int t = u.children[j];
                if (g[t].color == Brushes.White)
                {
                    g[t].pi = u;
                    dfsVisit(g, t);

                }
            }
            g[i].color = Brushes.Black;
            s = new Step(u.vertex, u.value, u.color);
            Draw.steps.Add(s);

            count++;
            u.timef = count;
        }

        public static void BFS(Graph[] g)
        {
            numberOfVertex = g.GetLength(0);
            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                if (g[i].mark == 0)
                    bfs(g, i);
            }
        }
        public static void bfs(Graph[] g, int i)
        {
            count++;
            g[i].mark = count;
            Graph u = g[i];
            Step s = new Step(u.vertex, u.value);
            Draw.steps.Add(s);

            s = new Step(new Point(u.vertex.X + 20, u.vertex.Y), (count).ToString(), true);
            Draw.steps.Add(s);

            List<Graph> que = new List<Graph>();
            que.Add(u);
            while (que.Count != 0)
            {
                Graph a = que[0];


                for (int j = 0; j < a.children.Count; j++)
                {
                    int t = a.children[j];
                    if (g[t].mark == 0)
                    {
                        count++;
                        g[t].mark = count;
                        que.Add(g[t]);

                        s = new Step(g[t].vertex, a.vertex, g[t].vertex, g[t].value);
                        Draw.steps.Add(s);

                        s = new Step(new Point(g[t].vertex.X + 20, g[t].vertex.Y), (count).ToString(), true);
                        Draw.steps.Add(s);

                    }
                }
                que.RemoveAt(0);
            }
        }

        public static void BFSC(Graph[] g)
        {
            numberOfVertex = g.GetLength(0);
            for (int i = 0; i < numberOfVertex - 1; i++)
            {
                if (g[i].color == Brushes.White)
                    bfsVisit(g, i);
            }
        }
        public static void bfsVisit(Graph[] g, int i)
        {
            count++;
            g[i].mark = count;
            g[i].color = Brushes.Gray;
            Graph u = g[i];

            Step s = new Step(u.vertex, u.value, u.color);
            Draw.steps.Add(s);

            List<Graph> que = new List<Graph>();
            que.Add(u);
            while (que.Count != 0)
            {
                Graph a = que[0];


                for (int j = 0; j < a.children.Count; j++)
                {
                    int t = a.children[j];
                    if (g[t].color == Brushes.White)
                    {
                        count++;
                        g[t].mark = count;
                        que.Add(g[t]);
                        g[t].color = Brushes.Gray;

                        s = new Step(g[t].vertex, a.vertex, g[t].vertex, g[t].value, g[t].color);
                        Draw.steps.Add(s);

                    }
                }
                a.color = Brushes.Black;
                s = new Step(a.vertex, a.value, a.color);
                Draw.steps.Add(s);

                que.RemoveAt(0);
            }

        }



    }
}
