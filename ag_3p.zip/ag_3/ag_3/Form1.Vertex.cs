﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
namespace ag_3
{
    partial class Form1
    {
        

        private void onVertexesNumberLeave(object sender, EventArgs e)
        {

            if (((TextBox)sender).Text == "" || ((TextBox)sender).Text == null || istrue) return;
            if (!isNumber(vertexesNumber))
            {
                vertexesLabels.Enabled = false;
                return;
            }
            vertexesLabels.Enabled = true;
            numberOfVertex = Convert.ToInt32(vertexesNumber.Text.Trim()) + 1;
            vertexesNamesCount = 1;
            boxSize = neghborArrayArea.Width / numberOfVertex; // add with me
            //h = 24;  // add with me 
            neghborArrayArea.Controls.Clear();
            neghborArrayArea.Controls.Add(neghborArrayLabel);
            neghboursArray = new TextBox[numberOfVertex, numberOfVertex];
            drawNeghboursArrayBox(neghborArrayArea, neghboursArray, 'n');
            vertexesNames = new string[numberOfVertex];
            //neghboursArrayValues = new int[numberOfVertex - 1, numberOfVertex - 1];
            nodes = new Point[numberOfVertex - 1];
            Draw.set(neghboursArray, vertexesNames);
            Draw.drawGraph(drawingArea);
            //draw();
            neghborArrayArea.Enabled = false; // added with me
            if (FormData.isWeighted)
            {
                //weightesArrayValuse = new int[numberOfVertex - 1, numberOfVertex - 1];
                createWeightsArrayArea();
            }
            vertexesLabels.Focus();
            istrue = true;
        }
        private void onVertexesLabelsKeyPress(object sender, KeyPressEventArgs e)
        {

            if (vertexesNamesCount >= numberOfVertex)
            {
                MessageBox.Show("تجاوزت عدد الرؤوس ...");
                e.Handled = true;
                return;
            }
            int key = e.KeyChar;
            string vertex = ((char)(key)).ToString();
            if ((key >= 65 && key <= 90) || (key >= 97 && key <= 122))
            {

                vertexesNames[vertexesNamesCount - 1] = vertex;
                neghboursArray[0, vertexesNamesCount].Text = vertex;
                neghboursArray[vertexesNamesCount, 0].Text = vertex;
                if (FormData.isWeighted)
                {
                    weightesArray[0, vertexesNamesCount].Text = vertex;
                    weightesArray[vertexesNamesCount, 0].Text = vertex;
                }
                Draw.drawNodeLabel(Draw.nodes[vertexesNamesCount - 1], vertex);
                vertexesLabels.Text = "";
                vertexesNamesCount++;
                if (vertexesNamesCount == numberOfVertex)
                {
                    neghborArrayArea.Enabled = true;
                    graphOrTree.Enabled = false;
                    dirOrUndir.Enabled = false;
                    weightedOrUnweighted.Enabled = false;
                    vertexesNumber.Enabled = false;
                    vertexesLabels.Enabled = false;

                    saveNeghborButton.Enabled = true;
                    editAllButton.Enabled = true;
                    deleteAllButton.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("ادخل قيمة صالحة ...");
                vertexesLabels.Focus();
            }

        }


    }
}
