﻿namespace ag_3
{
    partial class FormStep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.runStepsButton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.problemsList = new System.Windows.Forms.ComboBox();
            this.weightedOrUnweighted = new System.Windows.Forms.Panel();
            this.isUnweighted = new System.Windows.Forms.RadioButton();
            this.isWeighted = new System.Windows.Forms.RadioButton();
            this.vertexesNumber = new System.Windows.Forms.TextBox();
            this.dirOrUndir = new System.Windows.Forms.Panel();
            this.isUUndircted = new System.Windows.Forms.RadioButton();
            this.isDircted = new System.Windows.Forms.RadioButton();
            this.vertexesLabels = new System.Windows.Forms.TextBox();
            this.graphOrTree = new System.Windows.Forms.Panel();
            this.isGraph = new System.Windows.Forms.RadioButton();
            this.isTree = new System.Windows.Forms.RadioButton();
            this.vertexesLabelsLabel = new System.Windows.Forms.Label();
            this.graphProprerisLabel = new System.Windows.Forms.Label();
            this.vertexesNumberLabel = new System.Windows.Forms.Label();
            this.problem = new System.Windows.Forms.Label();
            this.algResultList = new System.Windows.Forms.ComboBox();
            this.algResult = new System.Windows.Forms.Label();
            this.requirementsList = new System.Windows.Forms.ComboBox();
            this.requirement = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.drawingArea = new System.Windows.Forms.Panel();
            this.drawingLabel = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.weightedOrUnweighted.SuspendLayout();
            this.dirOrUndir.SuspendLayout();
            this.graphOrTree.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.drawingArea.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.problemsList);
            this.panel3.Controls.Add(this.weightedOrUnweighted);
            this.panel3.Controls.Add(this.vertexesNumber);
            this.panel3.Controls.Add(this.dirOrUndir);
            this.panel3.Controls.Add(this.vertexesLabels);
            this.panel3.Controls.Add(this.graphOrTree);
            this.panel3.Controls.Add(this.vertexesLabelsLabel);
            this.panel3.Controls.Add(this.graphProprerisLabel);
            this.panel3.Controls.Add(this.vertexesNumberLabel);
            this.panel3.Controls.Add(this.problem);
            this.panel3.Controls.Add(this.algResultList);
            this.panel3.Controls.Add(this.algResult);
            this.panel3.Controls.Add(this.requirementsList);
            this.panel3.Controls.Add(this.requirement);
            this.panel3.Location = new System.Drawing.Point(21, 16);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1209, 131);
            this.panel3.TabIndex = 31;
            // 
            // problemsList
            // 
            this.problemsList.BackColor = System.Drawing.SystemColors.Info;
            this.problemsList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.problemsList.FormattingEnabled = true;
            this.problemsList.Location = new System.Drawing.Point(3, 8);
            this.problemsList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.problemsList.Name = "problemsList";
            this.problemsList.Size = new System.Drawing.Size(301, 24);
            this.problemsList.TabIndex = 20;
            // 
            // weightedOrUnweighted
            // 
            this.weightedOrUnweighted.Controls.Add(this.isUnweighted);
            this.weightedOrUnweighted.Controls.Add(this.isWeighted);
            this.weightedOrUnweighted.Location = new System.Drawing.Point(896, 37);
            this.weightedOrUnweighted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weightedOrUnweighted.Name = "weightedOrUnweighted";
            this.weightedOrUnweighted.Size = new System.Drawing.Size(93, 84);
            this.weightedOrUnweighted.TabIndex = 16;
            // 
            // isUnweighted
            // 
            this.isUnweighted.AutoSize = true;
            this.isUnweighted.Location = new System.Drawing.Point(3, 43);
            this.isUnweighted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isUnweighted.Name = "isUnweighted";
            this.isUnweighted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isUnweighted.Size = new System.Drawing.Size(85, 21);
            this.isUnweighted.TabIndex = 1;
            this.isUnweighted.Text = "غير موزون";
            this.isUnweighted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isUnweighted.UseVisualStyleBackColor = true;
            // 
            // isWeighted
            // 
            this.isWeighted.AutoSize = true;
            this.isWeighted.Location = new System.Drawing.Point(26, 15);
            this.isWeighted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isWeighted.Name = "isWeighted";
            this.isWeighted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isWeighted.Size = new System.Drawing.Size(62, 21);
            this.isWeighted.TabIndex = 0;
            this.isWeighted.Text = "موزون";
            this.isWeighted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isWeighted.UseVisualStyleBackColor = true;
            // 
            // vertexesNumber
            // 
            this.vertexesNumber.Location = new System.Drawing.Point(653, 77);
            this.vertexesNumber.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.vertexesNumber.Name = "vertexesNumber";
            this.vertexesNumber.Size = new System.Drawing.Size(116, 24);
            this.vertexesNumber.TabIndex = 26;
            // 
            // dirOrUndir
            // 
            this.dirOrUndir.Controls.Add(this.isUUndircted);
            this.dirOrUndir.Controls.Add(this.isDircted);
            this.dirOrUndir.Location = new System.Drawing.Point(996, 37);
            this.dirOrUndir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dirOrUndir.Name = "dirOrUndir";
            this.dirOrUndir.Size = new System.Drawing.Size(93, 84);
            this.dirOrUndir.TabIndex = 15;
            // 
            // isUUndircted
            // 
            this.isUUndircted.AutoSize = true;
            this.isUUndircted.Location = new System.Drawing.Point(10, 43);
            this.isUUndircted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isUUndircted.Name = "isUUndircted";
            this.isUUndircted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isUUndircted.Size = new System.Drawing.Size(82, 21);
            this.isUUndircted.TabIndex = 1;
            this.isUUndircted.Text = "غير موجه";
            this.isUUndircted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isUUndircted.UseVisualStyleBackColor = true;
            // 
            // isDircted
            // 
            this.isDircted.AutoSize = true;
            this.isDircted.Location = new System.Drawing.Point(33, 15);
            this.isDircted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isDircted.Name = "isDircted";
            this.isDircted.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isDircted.Size = new System.Drawing.Size(59, 21);
            this.isDircted.TabIndex = 0;
            this.isDircted.Text = "موجه";
            this.isDircted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isDircted.UseVisualStyleBackColor = true;
            // 
            // vertexesLabels
            // 
            this.vertexesLabels.Enabled = false;
            this.vertexesLabels.Location = new System.Drawing.Point(530, 77);
            this.vertexesLabels.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.vertexesLabels.Name = "vertexesLabels";
            this.vertexesLabels.Size = new System.Drawing.Size(116, 24);
            this.vertexesLabels.TabIndex = 25;
            // 
            // graphOrTree
            // 
            this.graphOrTree.Controls.Add(this.isGraph);
            this.graphOrTree.Controls.Add(this.isTree);
            this.graphOrTree.Location = new System.Drawing.Point(1096, 37);
            this.graphOrTree.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.graphOrTree.Name = "graphOrTree";
            this.graphOrTree.Size = new System.Drawing.Size(97, 84);
            this.graphOrTree.TabIndex = 14;
            // 
            // isGraph
            // 
            this.isGraph.AutoSize = true;
            this.isGraph.Location = new System.Drawing.Point(27, 43);
            this.isGraph.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isGraph.Name = "isGraph";
            this.isGraph.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isGraph.Size = new System.Drawing.Size(66, 21);
            this.isGraph.TabIndex = 1;
            this.isGraph.Text = "مخطط";
            this.isGraph.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isGraph.UseVisualStyleBackColor = true;
            // 
            // isTree
            // 
            this.isTree.AutoSize = true;
            this.isTree.Location = new System.Drawing.Point(28, 15);
            this.isTree.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.isTree.Name = "isTree";
            this.isTree.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.isTree.Size = new System.Drawing.Size(66, 21);
            this.isTree.TabIndex = 0;
            this.isTree.Text = "شجرة";
            this.isTree.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.isTree.UseVisualStyleBackColor = true;
            // 
            // vertexesLabelsLabel
            // 
            this.vertexesLabelsLabel.AutoSize = true;
            this.vertexesLabelsLabel.Location = new System.Drawing.Point(551, 38);
            this.vertexesLabelsLabel.Name = "vertexesLabelsLabel";
            this.vertexesLabelsLabel.Size = new System.Drawing.Size(102, 17);
            this.vertexesLabelsLabel.TabIndex = 24;
            this.vertexesLabelsLabel.Text = "تسميات الرؤوس";
            // 
            // graphProprerisLabel
            // 
            this.graphProprerisLabel.AutoSize = true;
            this.graphProprerisLabel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.graphProprerisLabel.Location = new System.Drawing.Point(970, 12);
            this.graphProprerisLabel.Name = "graphProprerisLabel";
            this.graphProprerisLabel.Size = new System.Drawing.Size(152, 21);
            this.graphProprerisLabel.TabIndex = 13;
            this.graphProprerisLabel.Text = "نوع الرسم وخصائصه";
            // 
            // vertexesNumberLabel
            // 
            this.vertexesNumberLabel.AutoSize = true;
            this.vertexesNumberLabel.Location = new System.Drawing.Point(698, 41);
            this.vertexesNumberLabel.Name = "vertexesNumberLabel";
            this.vertexesNumberLabel.Size = new System.Drawing.Size(77, 17);
            this.vertexesNumberLabel.TabIndex = 23;
            this.vertexesNumberLabel.Text = "عدد الرؤوس";
            // 
            // problem
            // 
            this.problem.AutoSize = true;
            this.problem.Location = new System.Drawing.Point(310, 11);
            this.problem.Name = "problem";
            this.problem.Size = new System.Drawing.Size(59, 17);
            this.problem.TabIndex = 17;
            this.problem.Text = "المشكلة";
            // 
            // algResultList
            // 
            this.algResultList.BackColor = System.Drawing.SystemColors.Info;
            this.algResultList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.algResultList.FormattingEnabled = true;
            this.algResultList.Location = new System.Drawing.Point(3, 100);
            this.algResultList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.algResultList.Name = "algResultList";
            this.algResultList.Size = new System.Drawing.Size(301, 24);
            this.algResultList.TabIndex = 22;
            // 
            // algResult
            // 
            this.algResult.AutoSize = true;
            this.algResult.Location = new System.Drawing.Point(308, 104);
            this.algResult.Name = "algResult";
            this.algResult.Size = new System.Drawing.Size(87, 17);
            this.algResult.TabIndex = 18;
            this.algResult.Text = "خوارزمية الحل";
            // 
            // requirementsList
            // 
            this.requirementsList.BackColor = System.Drawing.SystemColors.Info;
            this.requirementsList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.requirementsList.FormattingEnabled = true;
            this.requirementsList.Location = new System.Drawing.Point(3, 57);
            this.requirementsList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.requirementsList.Name = "requirementsList";
            this.requirementsList.Size = new System.Drawing.Size(301, 24);
            this.requirementsList.TabIndex = 21;
            // 
            // requirement
            // 
            this.requirement.AutoSize = true;
            this.requirement.Location = new System.Drawing.Point(313, 62);
            this.requirement.Name = "requirement";
            this.requirement.Size = new System.Drawing.Size(56, 17);
            this.requirement.TabIndex = 19;
            this.requirement.Text = "المطلوب";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.drawingArea);
            this.panel1.Location = new System.Drawing.Point(21, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1209, 545);
            this.panel1.TabIndex = 30;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(12, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(690, 517);
            this.panel2.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FloralWhite;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F);
            this.label1.Location = new System.Drawing.Point(263, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 23);
            this.label1.TabIndex = 13;
            this.label1.Text = "خطوات وبيانات الحل";
            // 
            // drawingArea
            // 
            this.drawingArea.BackColor = System.Drawing.SystemColors.GrayText;
            this.drawingArea.Controls.Add(this.drawingLabel);
            this.drawingArea.Location = new System.Drawing.Point(708, 13);
            this.drawingArea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.drawingArea.Name = "drawingArea";
            this.drawingArea.Size = new System.Drawing.Size(498, 517);
            this.drawingArea.TabIndex = 27;
            // 
            // drawingLabel
            // 
            this.drawingLabel.AutoSize = true;
            this.drawingLabel.BackColor = System.Drawing.Color.FloralWhite;
            this.drawingLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.drawingLabel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.drawingLabel.Location = new System.Drawing.Point(185, 0);
            this.drawingLabel.Name = "drawingLabel";
            this.drawingLabel.Size = new System.Drawing.Size(57, 23);
            this.drawingLabel.TabIndex = 12;
            this.drawingLabel.Text = "الرسم";
            // 
            // FormStep
            //
            
            
            this.runStepsButton.Location = new System.Drawing.Point(639, 695);
            this.runStepsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.runStepsButton.Name = "runStepsButton";
            this.runStepsButton.Size = new System.Drawing.Size(133, 39);
            this.runStepsButton.TabIndex = 17;
            this.runStepsButton.Text = "التنفيذ خطوة - خطوة";
            this.runStepsButton.UseVisualStyleBackColor = true;
            this.runStepsButton.Click += new System.EventHandler(this.runStepsButton_Click);
            
            
             
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1242, 700);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.runStepsButton);

            this.Name = "FormStep";
            this.Text = "FormStep";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.weightedOrUnweighted.ResumeLayout(false);
            this.weightedOrUnweighted.PerformLayout();
            this.dirOrUndir.ResumeLayout(false);
            this.dirOrUndir.PerformLayout();
            this.graphOrTree.ResumeLayout(false);
            this.graphOrTree.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.drawingArea.ResumeLayout(false);
            this.drawingArea.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox problemsList;
        private System.Windows.Forms.Panel weightedOrUnweighted;
        private System.Windows.Forms.RadioButton isUnweighted;
        private System.Windows.Forms.RadioButton isWeighted;
        private System.Windows.Forms.TextBox vertexesNumber;
        private System.Windows.Forms.Panel dirOrUndir;
        private System.Windows.Forms.RadioButton isUUndircted;
        private System.Windows.Forms.RadioButton isDircted;
        private System.Windows.Forms.TextBox vertexesLabels;
        private System.Windows.Forms.Panel graphOrTree;
        private System.Windows.Forms.RadioButton isGraph;
        private System.Windows.Forms.RadioButton isTree;
        private System.Windows.Forms.Label vertexesLabelsLabel;
        private System.Windows.Forms.Label graphProprerisLabel;
        private System.Windows.Forms.Label vertexesNumberLabel;
        private System.Windows.Forms.Label problem;
        private System.Windows.Forms.ComboBox algResultList;
        private System.Windows.Forms.Label algResult;
        private System.Windows.Forms.ComboBox requirementsList;
        private System.Windows.Forms.Label requirement;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel drawingArea;
        private System.Windows.Forms.Label drawingLabel;
        private System.Windows.Forms.Button runStepsButton;

    }
}