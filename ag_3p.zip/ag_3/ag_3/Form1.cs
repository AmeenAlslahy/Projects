﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace ag_3
{

    public partial class Form1 : Form
    {
        TextBox[,] neghboursArray;
        TextBox[,] weightesArray;
        string[] vertexesNames;
        int vertexesNamesCount = 0;
        int numberOfVertex;
        Point[] nodes;
        
        const int cirSize = 30;
        Font font = new Font("Arial", cirSize / 2);
        Graphics graphics;
        int boxSize;
        int margin =20;
        bool istrue = false;
        FormStep fstp;
        public Form1()
        {
            InitializeComponent();
            graphics = drawingArea.CreateGraphics();
            problemsList.Enabled = true;
        }



        private void runStepsButton_Click(object sender, EventArgs e)
        {
           
            neghborArrayArea.Width *= 2;
            neghborArrayLabel.Text = "الرسم";

            neghborArrayLabel.Left = neghborArrayArea.Width / 2;
            drawingLabel.Text = "التنفيذ";


            string problem = problemsList.Text;
            string reqierd = requirementsList.Text;
            string solve = algResultList.Text;

            fstp = new FormStep(vertexesLabels.Text, problem, reqierd, solve);
            fstp.Show();
            //fstp.Dispose();
            //this.Visible = false;
        }

        private void onLoadForm(object sender, EventArgs e)
        {
            vertexesNumber.Enabled = false;
            enabels(false);

            weightedOrUnweighted.Enabled = false;
            vertexesNumber.Text = vertexesLabels.Text = "";

            weightsArrayArea.Controls.Clear();
            weightsArrayArea.Controls.Add(weightsArrayLabel);

            neghborArrayArea.Controls.Clear();
            neghborArrayArea.Controls.Add(neghborArrayLabel);

            graphics.Clear(drawingArea.BackColor);
            vertexesNumber.Leave += onVertexesNumberLeave;

        }
        void enabels(bool f)
        {
            graphOrTree.Enabled = !f;
            weightedOrUnweighted.Enabled = f;
            dirOrUndir.Enabled = f;

            problemsList.Enabled = f;
            algResultList.Enabled = f;
            requirementsList.Enabled = f;

            vertexesLabels.Enabled = f;
            weightsArrayArea.Enabled = f;
            weightsArrayArea.Visible = f;

            editAllButton.Enabled = f;
            deleteAllButton.Enabled = f;
            runStepsButton.Enabled = f;

            editWeightsButton.Enabled = f;
            deleteWeightsButton.Enabled = f;
            saveNeghborButton.Enabled = f;

            editNeghborButton.Enabled = f;
            deleteNeghborButton.Enabled = f;
            saveWeightsButton.Enabled = false;


        }
       

       
        private void editAllButton_Click(object sender, EventArgs e)
        {
            istrue = false;
            graphOrTree.Enabled = true;
            vertexesNumber.Enabled = true;

           
        }
        
        

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (sender == deleteNeghborButton)
                deleteArraysButton(neghboursArray);
            else
                deleteArraysButton(weightesArray);
            Draw.graphics.Clear(drawingArea.BackColor);
        }

    }
}
